# UNIFED-PROBATUM v13.12.3-PRO — GitHub Deploy

## Ponto de entrada
Abrir `panel.html` no browser ou servir via GitHub Pages / servidor local.

## Estrutura de carregamento (ordem obrigatória em panel.html)
```
panel.html  ← entry point
│
├── style.css
├── style_additions.css
├── style_additions_patch.css
│
├── script.js                        ← motor principal (453 KB)
├── nexus.js
├── enrichment.js
├── script_injection.js
├── proxy_worker.js
│
├── unifed_panel_activator.js
├── unifed_access_control.js
├── unifed_card_amt01.js
├── unifed_core_harmonizer.js
├── unifed_orchestrator.js
├── unifed_holographic_dashboard.js
├── unifed_ingestion_engine_v2.0.js  ← v29991 bytes (mais recente)
├── unifed_custody_engine_v2.0.js
├── unifed_contradictory_engine.js
├── unifed_triada_export.js
│
├── forensic_seal_engine.js
├── provenance_logger.js
├── audit_uncertainty_engine_v1.0.js
│
├── legal_tactics_engine_v1.0.js        ← Bateria 50 Questões
├── legal_tactics_ui_v1.0.js            ← Interface Acordeão
├── legal_tactics_pdf_export_v1.0.js    ← Export PDF Guião
├── legal_tactics_orchestrator_v1.0.js  ← Orquestrador
└── INTEGRATION_MANIFEST_v13.12.3-PRO.js
```

## Verificação rápida no browser (console)
```javascript
// 1. Verificar dependências
window.UNIFED_LEGAL_TACTICS_ORCHESTRATOR.checkDependencies()

// 2. Teste de desbloqueio manual
window.UNIFED_LEGAL_TACTICS_ORCHESTRATOR.unlockOnForensicComplete({
    discrepancia_c2: 2184.95,
    comissaoIndevida: 500.00,
    caseId: 'TEST-2024-001'
})
```

## Conformidade
- Art. 327.º CPP — Direito ao Contraditório  
- ISO/IEC 27037:2012 — Preservação de Evidência Digital  
- DAC7 (UE) 2021/514 | DORA (UE) 2022/2554  
- Master Hash: ver MANIFEST_SHA256_v13.12.3-PRO.json

## Nota sobre index.html
O ficheiro `index.html` nesta pasta corresponde ao `index_v13.12.3_PRO_FINAL.html` 
(106.518 bytes — versão final de 2026-04-20 01:27), renomeado para entry point GitHub Pages.

---
*Gerado automaticamente em 2026-04-20. Versão canónica: v13.12.3-PRO.*
